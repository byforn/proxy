// Set this to your Wisp server, e.g. "wss://vilation-wisp.onrender.com/wisp/".
// Leave empty to use the same host as the site (when the Node server hosts everything).
window.WISP_URL = "";
