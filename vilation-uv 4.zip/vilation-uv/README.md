# Vilation

## Option A: everything on one Node host (simplest)
Render, Railway, Koyeb, a VPS: `npm install`, then `npm start`. Leave `public/config.js` as is.

## Option B: Netlify front-end + Node host for the tunnel
Netlify can’t run the /wisp/ websocket server, so split it:
1. Deploy this same repo on a Node host (Render web service: build `npm install`, start `npm start`).
2. Put its address in `public/config.js`, e.g. `window.WISP_URL = "wss://YOUR-APP.onrender.com/wisp/";`
3. On Netlify, import the repo from GitHub. `netlify.toml` already sets build `npm install && node build.js` and publish folder `dist`.
   (Drag-and-drop of the raw folder or a zip won’t run the build, which causes a 404.)
