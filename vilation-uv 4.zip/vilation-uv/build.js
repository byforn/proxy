import { cpSync, rmSync, mkdirSync } from "node:fs";
import { uvPath } from "@titaniumnetwork-dev/ultraviolet";
import { epoxyPath } from "@mercuryworkshop/epoxy-transport";
import { baremuxPath } from "@mercuryworkshop/bare-mux/node";

rmSync("dist", { recursive: true, force: true });
mkdirSync("dist", { recursive: true });
// Vendor files first, then our public folder on top (so our uv.config.js wins).
cpSync(uvPath, "dist/uv", { recursive: true });
cpSync(epoxyPath, "dist/epoxy", { recursive: true });
cpSync(baremuxPath, "dist/baremux", { recursive: true });
cpSync("public", "dist", { recursive: true, force: true });
console.log("Built dist/");
